# Run report: industry25-r1

| condition | n | exec rate | accuracy | correct | mean out tokens | mean calls | repaired |
|---|---|---|---|---|---|---|---|
| C3L | 25 | 0.92 | 0.48 | 12 | 1063.8 | 1.48 | 12 |

## C3L: hard gene failures (round0 -> final)
- orgene.boundary.solve_before_report: 1 -> 0
- orgene.boundary.status_reported: 1 -> 0
- orgene.code.pulp_api_exists: 1 -> 2
- orgene.constraints.rows_sign_feasible: 2 -> 1
- orgene.execution.runs: 4 -> 2
- orgene.model.binary_cardinality_linked: 2 -> 2
- orgene.model.linear_expressions_only: 4 -> 0
- orgene.model.logic_via_indicators: 3 -> 0
- orgene.solution.nontrivial_optimum: 1 -> 0
- orgene.solution.status_optimal_or_justified: 6 -> 7

