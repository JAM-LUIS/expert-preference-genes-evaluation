# Run report: mamo30-r1

| condition | n | exec rate | accuracy | correct | mean out tokens | mean calls | repaired |
|---|---|---|---|---|---|---|---|
| C3L | 30 | 0.9333 | 0.7 | 21 | 869.3 | 1.433 | 13 |

## C3L: hard gene failures (round0 -> final)
- orgene.code.sparse_index_guard: 0 -> 1
- orgene.code.tuple_key_indexing: 3 -> 1
- orgene.execution.runs: 6 -> 2
- orgene.model.linear_expressions_only: 1 -> 0
- orgene.objective.aggregates_declared_variables: 4 -> 0
- orgene.solution.nontrivial_optimum: 1 -> 2
- orgene.solution.status_optimal_or_justified: 8 -> 3

